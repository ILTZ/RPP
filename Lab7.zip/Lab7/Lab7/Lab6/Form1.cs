﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;





using System.Data.OleDb;

namespace Lab6
{
    public partial class Form1 : Form
    {

        Class2 formClass2;


        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            oleDbDataAdapter1.Fill(dataTable1);
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            formClass2 = new Class2();
            Control[] lbs = formClass2.Controls.Find("label4", true);
            lbs[0].Text = "1";

            formClass2.ShowDialog();
            dataSet1.Clear();
            oleDbDataAdapter1.Fill(dataTable1);

            buttonChange.Enabled = dataGridView1.Rows.Count > 0;
            buttonDelete.Enabled = dataGridView1.Rows.Count > 0;
        }

        private void buttonChange_Click(object sender, EventArgs e)
        {
            formClass2 = new Class2();

            Control[] lbs = formClass2.Controls.Find("label4", true);
            lbs[0].Text = "2";

            Control[] lbs1 = formClass2.Controls.Find("label5", true);
            lbs1[0].Text = dataGridView1[0, dataGridView1.CurrentRow.Index].Value.ToString();

            for (int i = 1; i < 4; ++i)
            {
                Control[] tbxs = formClass2.Controls.Find("textBox" + i, true);
                tbxs[0].Text = dataGridView1[i, dataGridView1.CurrentRow.Index].Value.ToString();
            }


            formClass2.ShowDialog();
            dataSet1.Clear();
            oleDbDataAdapter1.Fill(dataTable1);
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            string caption = "Удаление записи";
            string message = "Вы уверены, что хотите удалить запись " + dataGridView1[1, dataGridView1.CurrentRow.Index].Value.ToString() + " ?";
            DialogResult result = MessageBox.Show(message, caption, MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                OleDbConnection conn = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0; Data Source=C:\Game\Lab7\Lab7\contacts.mdb");

                OleDbCommand cmd = new OleDbCommand("", conn);

                try
                {
                    conn.Open();
                    cmd.CommandText = "delete from contacts where cid=" +
                        dataGridView1[0, dataGridView1.CurrentRow.Index].Value.ToString();
                    cmd.ExecuteNonQuery();
                }
                catch(Exception ex)
                {
                    System.Windows.Forms.MessageBox.Show(ex.Message);
                }
                finally
                {
                    conn.Close();
                }

                dataSet1.Clear();
                oleDbDataAdapter1.Fill(dataTable1);

                buttonChange.Enabled = dataGridView1.Rows.Count > 0;
                buttonDelete.Enabled = dataGridView1.Rows.Count > 0;

            }
        }

 
    }
}
