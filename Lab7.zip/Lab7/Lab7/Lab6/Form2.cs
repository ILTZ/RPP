﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


using System.Data.OleDb;

namespace Lab6
{
    public partial class Form2 : Form
    {

        

        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            OleDbConnection conn = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0; Data Source=C:\Game\Lab7\Lab7\contacts.mdb");
            OleDbCommand cmd = new OleDbCommand("", conn);

            try
            {
                conn.Open();


                switch(label4.Text)
                {
                    case "1":
                        cmd.CommandText = "insert into contacts (name, phone, email)";
                        cmd.CommandText += " values('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "')";
                        break;

                    case "2":
                        cmd.CommandText = "update contacts set name='" + textBox1.Text + "'";
                        cmd.CommandText += ",phone='" + textBox2.Text + "'";
                        cmd.CommandText += ",email='" + textBox3.Text + "'";
                        cmd.CommandText += " where cid=" + label5.Text;
                        break;

                    default:
                        break;




                }


                cmd.ExecuteNonQuery();
                Dispose();

            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }




        }

        private void buttonCancle_Click(object sender, EventArgs e)
        {
            Dispose();
        }
    }
}
